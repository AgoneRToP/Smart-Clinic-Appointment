export * from "./doctors.model";
