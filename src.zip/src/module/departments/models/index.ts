export * from "./department.model";
